[
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "admin",
    "model": "logentry"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "auth",
    "model": "permission"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "auth",
    "model": "group"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "contenttypes",
    "model": "contenttype"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "sessions",
    "model": "session"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "accounts",
    "model": "user"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "accounts",
    "model": "emailverification"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "accounts",
    "model": "passwordreset"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "courses",
    "model": "courseenrollment"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "courses",
    "model": "coursereview"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "courses",
    "model": "courselike"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "courses",
    "model": "course"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "courses",
    "model": "lesson"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "chat",
    "model": "message"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "chat",
    "model": "supportchat"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "accounts",
    "model": "notification"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "adminpanel",
    "model": "popularcontent"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "adminpanel",
    "model": "systemlog"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "adminpanel",
    "model": "usersession"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "adminpanel",
    "model": "errorlog"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "adminpanel",
    "model": "backuplog"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "adminpanel",
    "model": "activitylog"
  }
},
{
  "model": "sessions.session",
  "pk": "9rd3k99ofc9t91u8z1wv8j4dkctg2biz",
  "fields": {
    "session_data": ".eJxVjLsOwjAMAP_FM4ryKiQd2fmGynYcUkCJ1LQT4t9RpQ6w3p3uDRNua5m2Lss0JxjBwumXEfJT6i7SA-u9KW51XWZSe6IO29WtJXldj_ZvULAXGIEpmmjIUAxkfUqerLWiDYoxGQer2bnMDkMIifSFgx-QyZEmzBrPAp8v7rw4lA:1vxpyi:yRkZTAnOontaap7zjWYKBrhfsqMewYCN-LC0NH8ut4Y",
    "expire_date": "2026-03-18T17:25:44.792Z"
  }
},
{
  "model": "courses.lesson",
  "pk": 1,
  "fields": {
    "course": 1,
    "title": "такой",
    "lesson_type": "text",
    "order": 1,
    "video_url": null,
    "content": "",
    "file": "lessons/files/ПР_8_Калькуляция_и_смета_затрат.docx",
    "video_file": "",
    "comment": "",
    "created_at": "2026-02-20T15:48:04.939Z",
    "updated_at": "2026-02-20T15:48:04.939Z"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add log entry",
    "content_type": [
      "admin",
      "logentry"
    ],
    "codename": "add_logentry"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change log entry",
    "content_type": [
      "admin",
      "logentry"
    ],
    "codename": "change_logentry"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete log entry",
    "content_type": [
      "admin",
      "logentry"
    ],
    "codename": "delete_logentry"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view log entry",
    "content_type": [
      "admin",
      "logentry"
    ],
    "codename": "view_logentry"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add permission",
    "content_type": [
      "auth",
      "permission"
    ],
    "codename": "add_permission"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change permission",
    "content_type": [
      "auth",
      "permission"
    ],
    "codename": "change_permission"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete permission",
    "content_type": [
      "auth",
      "permission"
    ],
    "codename": "delete_permission"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view permission",
    "content_type": [
      "auth",
      "permission"
    ],
    "codename": "view_permission"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add group",
    "content_type": [
      "auth",
      "group"
    ],
    "codename": "add_group"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change group",
    "content_type": [
      "auth",
      "group"
    ],
    "codename": "change_group"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete group",
    "content_type": [
      "auth",
      "group"
    ],
    "codename": "delete_group"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view group",
    "content_type": [
      "auth",
      "group"
    ],
    "codename": "view_group"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add content type",
    "content_type": [
      "contenttypes",
      "contenttype"
    ],
    "codename": "add_contenttype"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change content type",
    "content_type": [
      "contenttypes",
      "contenttype"
    ],
    "codename": "change_contenttype"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete content type",
    "content_type": [
      "contenttypes",
      "contenttype"
    ],
    "codename": "delete_contenttype"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view content type",
    "content_type": [
      "contenttypes",
      "contenttype"
    ],
    "codename": "view_contenttype"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add session",
    "content_type": [
      "sessions",
      "session"
    ],
    "codename": "add_session"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change session",
    "content_type": [
      "sessions",
      "session"
    ],
    "codename": "change_session"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete session",
    "content_type": [
      "sessions",
      "session"
    ],
    "codename": "delete_session"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view session",
    "content_type": [
      "sessions",
      "session"
    ],
    "codename": "view_session"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add Пользователь",
    "content_type": [
      "accounts",
      "user"
    ],
    "codename": "add_user"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change Пользователь",
    "content_type": [
      "accounts",
      "user"
    ],
    "codename": "change_user"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete Пользователь",
    "content_type": [
      "accounts",
      "user"
    ],
    "codename": "delete_user"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view Пользователь",
    "content_type": [
      "accounts",
      "user"
    ],
    "codename": "view_user"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add Подтверждение email",
    "content_type": [
      "accounts",
      "emailverification"
    ],
    "codename": "add_emailverification"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change Подтверждение email",
    "content_type": [
      "accounts",
      "emailverification"
    ],
    "codename": "change_emailverification"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete Подтверждение email",
    "content_type": [
      "accounts",
      "emailverification"
    ],
    "codename": "delete_emailverification"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view Подтверждение email",
    "content_type": [
      "accounts",
      "emailverification"
    ],
    "codename": "view_emailverification"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add Сброс пароля",
    "content_type": [
      "accounts",
      "passwordreset"
    ],
    "codename": "add_passwordreset"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change Сброс пароля",
    "content_type": [
      "accounts",
      "passwordreset"
    ],
    "codename": "change_passwordreset"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete Сброс пароля",
    "content_type": [
      "accounts",
      "passwordreset"
    ],
    "codename": "delete_passwordreset"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view Сброс пароля",
    "content_type": [
      "accounts",
      "passwordreset"
    ],
    "codename": "view_passwordreset"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add Запись на курс",
    "content_type": [
      "courses",
      "courseenrollment"
    ],
    "codename": "add_courseenrollment"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change Запись на курс",
    "content_type": [
      "courses",
      "courseenrollment"
    ],
    "codename": "change_courseenrollment"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete Запись на курс",
    "content_type": [
      "courses",
      "courseenrollment"
    ],
    "codename": "delete_courseenrollment"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view Запись на курс",
    "content_type": [
      "courses",
      "courseenrollment"
    ],
    "codename": "view_courseenrollment"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add Отзыв о курсе",
    "content_type": [
      "courses",
      "coursereview"
    ],
    "codename": "add_coursereview"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change Отзыв о курсе",
    "content_type": [
      "courses",
      "coursereview"
    ],
    "codename": "change_coursereview"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete Отзыв о курсе",
    "content_type": [
      "courses",
      "coursereview"
    ],
    "codename": "delete_coursereview"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view Отзыв о курсе",
    "content_type": [
      "courses",
      "coursereview"
    ],
    "codename": "view_coursereview"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add Лайк курса",
    "content_type": [
      "courses",
      "courselike"
    ],
    "codename": "add_courselike"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change Лайк курса",
    "content_type": [
      "courses",
      "courselike"
    ],
    "codename": "change_courselike"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete Лайк курса",
    "content_type": [
      "courses",
      "courselike"
    ],
    "codename": "delete_courselike"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view Лайк курса",
    "content_type": [
      "courses",
      "courselike"
    ],
    "codename": "view_courselike"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add Курс",
    "content_type": [
      "courses",
      "course"
    ],
    "codename": "add_course"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change Курс",
    "content_type": [
      "courses",
      "course"
    ],
    "codename": "change_course"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete Курс",
    "content_type": [
      "courses",
      "course"
    ],
    "codename": "delete_course"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view Курс",
    "content_type": [
      "courses",
      "course"
    ],
    "codename": "view_course"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add Урок",
    "content_type": [
      "courses",
      "lesson"
    ],
    "codename": "add_lesson"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change Урок",
    "content_type": [
      "courses",
      "lesson"
    ],
    "codename": "change_lesson"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete Урок",
    "content_type": [
      "courses",
      "lesson"
    ],
    "codename": "delete_lesson"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view Урок",
    "content_type": [
      "courses",
      "lesson"
    ],
    "codename": "view_lesson"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add message",
    "content_type": [
      "chat",
      "message"
    ],
    "codename": "add_message"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change message",
    "content_type": [
      "chat",
      "message"
    ],
    "codename": "change_message"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete message",
    "content_type": [
      "chat",
      "message"
    ],
    "codename": "delete_message"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view message",
    "content_type": [
      "chat",
      "message"
    ],
    "codename": "view_message"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add support chat",
    "content_type": [
      "chat",
      "supportchat"
    ],
    "codename": "add_supportchat"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change support chat",
    "content_type": [
      "chat",
      "supportchat"
    ],
    "codename": "change_supportchat"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete support chat",
    "content_type": [
      "chat",
      "supportchat"
    ],
    "codename": "delete_supportchat"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view support chat",
    "content_type": [
      "chat",
      "supportchat"
    ],
    "codename": "view_supportchat"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add Уведомление",
    "content_type": [
      "accounts",
      "notification"
    ],
    "codename": "add_notification"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change Уведомление",
    "content_type": [
      "accounts",
      "notification"
    ],
    "codename": "change_notification"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete Уведомление",
    "content_type": [
      "accounts",
      "notification"
    ],
    "codename": "delete_notification"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view Уведомление",
    "content_type": [
      "accounts",
      "notification"
    ],
    "codename": "view_notification"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add Популярный контент",
    "content_type": [
      "adminpanel",
      "popularcontent"
    ],
    "codename": "add_popularcontent"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change Популярный контент",
    "content_type": [
      "adminpanel",
      "popularcontent"
    ],
    "codename": "change_popularcontent"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete Популярный контент",
    "content_type": [
      "adminpanel",
      "popularcontent"
    ],
    "codename": "delete_popularcontent"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view Популярный контент",
    "content_type": [
      "adminpanel",
      "popularcontent"
    ],
    "codename": "view_popularcontent"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add Системный лог",
    "content_type": [
      "adminpanel",
      "systemlog"
    ],
    "codename": "add_systemlog"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change Системный лог",
    "content_type": [
      "adminpanel",
      "systemlog"
    ],
    "codename": "change_systemlog"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete Системный лог",
    "content_type": [
      "adminpanel",
      "systemlog"
    ],
    "codename": "delete_systemlog"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view Системный лог",
    "content_type": [
      "adminpanel",
      "systemlog"
    ],
    "codename": "view_systemlog"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add Сессия пользователя",
    "content_type": [
      "adminpanel",
      "usersession"
    ],
    "codename": "add_usersession"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change Сессия пользователя",
    "content_type": [
      "adminpanel",
      "usersession"
    ],
    "codename": "change_usersession"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete Сессия пользователя",
    "content_type": [
      "adminpanel",
      "usersession"
    ],
    "codename": "delete_usersession"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view Сессия пользователя",
    "content_type": [
      "adminpanel",
      "usersession"
    ],
    "codename": "view_usersession"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add Лог ошибок",
    "content_type": [
      "adminpanel",
      "errorlog"
    ],
    "codename": "add_errorlog"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change Лог ошибок",
    "content_type": [
      "adminpanel",
      "errorlog"
    ],
    "codename": "change_errorlog"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete Лог ошибок",
    "content_type": [
      "adminpanel",
      "errorlog"
    ],
    "codename": "delete_errorlog"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view Лог ошибок",
    "content_type": [
      "adminpanel",
      "errorlog"
    ],
    "codename": "view_errorlog"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add Лог бэкапа",
    "content_type": [
      "adminpanel",
      "backuplog"
    ],
    "codename": "add_backuplog"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change Лог бэкапа",
    "content_type": [
      "adminpanel",
      "backuplog"
    ],
    "codename": "change_backuplog"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete Лог бэкапа",
    "content_type": [
      "adminpanel",
      "backuplog"
    ],
    "codename": "delete_backuplog"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view Лог бэкапа",
    "content_type": [
      "adminpanel",
      "backuplog"
    ],
    "codename": "view_backuplog"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add Лог активности",
    "content_type": [
      "adminpanel",
      "activitylog"
    ],
    "codename": "add_activitylog"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change Лог активности",
    "content_type": [
      "adminpanel",
      "activitylog"
    ],
    "codename": "change_activitylog"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete Лог активности",
    "content_type": [
      "adminpanel",
      "activitylog"
    ],
    "codename": "delete_activitylog"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view Лог активности",
    "content_type": [
      "adminpanel",
      "activitylog"
    ],
    "codename": "view_activitylog"
  }
},
{
  "model": "accounts.user",
  "fields": {
    "password": "pbkdf2_sha256$870000$WuuaZkba5M70ShFpz68Pxq$HH6HPwZpLf+ymz/hMxqTprIPuOGTUv8ILU8qFxy6ZNM=",
    "last_login": "2026-02-25T08:46:00.559Z",
    "is_superuser": false,
    "username": "ццввцвцв",
    "first_name": "Уо",
    "last_name": "Уоо",
    "is_staff": false,
    "is_active": true,
    "date_joined": "2026-02-19T22:26:29.784Z",
    "email": "lehaprorok228@gmail.com",
    "role": "student",
    "phone": null,
    "avatar": "avatars/Снимок_экрана_2026-02-18_202941_u8KSgka.png",
    "teaching_document": "",
    "is_email_verified": false,
    "date_of_birth": null,
    "bio": "",
    "created_at": "2026-02-19T22:26:30.257Z",
    "updated_at": "2026-02-20T19:43:35.837Z",
    "groups": [],
    "user_permissions": []
  }
},
{
  "model": "accounts.user",
  "fields": {
    "password": "pbkdf2_sha256$870000$gBwKJP10ZKYMQn9BHxCbJw$PGE36oLmu6Jz+CK+HPe9SxllTannY1T/6wzscGIUUPs=",
    "last_login": "2026-03-04T17:25:44.781Z",
    "is_superuser": true,
    "username": "РђРґРјРёРЅР°",
    "first_name": "Admin",
    "last_name": "SuperUser",
    "is_staff": true,
    "is_active": true,
    "date_joined": "2026-02-20T07:16:41.311Z",
    "email": "pashokbilashenko335@gmail.com",
    "role": "admin",
    "phone": null,
    "avatar": "",
    "teaching_document": "",
    "is_email_verified": false,
    "date_of_birth": null,
    "bio": "",
    "created_at": "2026-02-20T07:16:41.722Z",
    "updated_at": "2026-02-20T07:16:41.734Z",
    "groups": [],
    "user_permissions": []
  }
},
{
  "model": "accounts.user",
  "fields": {
    "password": "pbkdf2_sha256$870000$5SEU7te0zCgT0KaaBlf0LP$5AVJKtWY60UmFKHiy6jrLfbC1mO70citnDp02n58has=",
    "last_login": "2026-02-24T08:31:42.312Z",
    "is_superuser": false,
    "username": "DefaultAuthor",
    "first_name": "Default",
    "last_name": "Author",
    "is_staff": false,
    "is_active": true,
    "date_joined": "2026-02-20T09:12:57.841Z",
    "email": "author@progauge.com",
    "role": "author",
    "phone": null,
    "avatar": "avatars/image_GTmihTo.png",
    "teaching_document": "",
    "is_email_verified": false,
    "date_of_birth": null,
    "bio": "",
    "created_at": "2026-02-20T09:12:58.143Z",
    "updated_at": "2026-02-20T10:38:32.668Z",
    "groups": [],
    "user_permissions": []
  }
},
{
  "model": "accounts.emailverification",
  "pk": 1,
  "fields": {
    "user": [
      "lehaprorok228@gmail.com"
    ],
    "token": "ac762ac2-9e89-42af-bc34-6c2ac94a07b6",
    "created_at": "2026-02-19T22:26:30.266Z",
    "is_used": false
  }
},
{
  "model": "accounts.passwordreset",
  "pk": 1,
  "fields": {
    "user": [
      "lehaprorok228@gmail.com"
    ],
    "token": "f1edd7c8-b1cd-403c-b956-4188cfc91d52",
    "created_at": "2026-02-20T19:42:25.860Z",
    "is_used": false
  }
},
{
  "model": "accounts.notification",
  "pk": 1,
  "fields": {
    "user": [
      "lehaprorok228@gmail.com"
    ],
    "message": "Новое сообщение от поддержки: ыыфы...",
    "is_read": true,
    "created_at": "2026-02-20T19:15:52.322Z"
  }
},
{
  "model": "accounts.notification",
  "pk": 2,
  "fields": {
    "user": [
      "lehaprorok228@gmail.com"
    ],
    "message": "Новое сообщение от поддержки: ыыввы...",
    "is_read": true,
    "created_at": "2026-02-20T19:20:59.345Z"
  }
},
{
  "model": "accounts.notification",
  "pk": 3,
  "fields": {
    "user": [
      "lehaprorok228@gmail.com"
    ],
    "message": "Новое сообщение от поддержки: jhhj...",
    "is_read": true,
    "created_at": "2026-02-20T19:22:29.323Z"
  }
},
{
  "model": "accounts.notification",
  "pk": 4,
  "fields": {
    "user": [
      "lehaprorok228@gmail.com"
    ],
    "message": "Новое сообщение от поддержки: вцауц...",
    "is_read": true,
    "created_at": "2026-02-20T19:25:53.298Z"
  }
},
{
  "model": "accounts.notification",
  "pk": 5,
  "fields": {
    "user": [
      "lehaprorok228@gmail.com"
    ],
    "message": "Новое сообщение от поддержки: ув...",
    "is_read": true,
    "created_at": "2026-02-20T19:27:09.595Z"
  }
},
{
  "model": "accounts.notification",
  "pk": 6,
  "fields": {
    "user": [
      "lehaprorok228@gmail.com"
    ],
    "message": "Новое сообщение от поддержки: увау...",
    "is_read": true,
    "created_at": "2026-02-20T19:32:15.055Z"
  }
},
{
  "model": "accounts.notification",
  "pk": 7,
  "fields": {
    "user": [
      "lehaprorok228@gmail.com"
    ],
    "message": "Новое сообщение от поддержки: igyfuy...",
    "is_read": true,
    "created_at": "2026-02-24T08:35:48.724Z"
  }
},
{
  "model": "accounts.notification",
  "pk": 8,
  "fields": {
    "user": [
      "lehaprorok228@gmail.com"
    ],
    "message": "Новое сообщение от поддержки: ининр...",
    "is_read": true,
    "created_at": "2026-02-25T08:45:53.171Z"
  }
},
{
  "model": "accounts.notification",
  "pk": 9,
  "fields": {
    "user": [
      "pashokbilashenko335@gmail.com"
    ],
    "message": "Новое сообщение в поддержке от ццввцвцв: цауца...",
    "is_read": true,
    "created_at": "2026-02-25T08:50:41.643Z"
  }
},
{
  "model": "accounts.notification",
  "pk": 10,
  "fields": {
    "user": [
      "pashokbilashenko335@gmail.com"
    ],
    "message": "Новое сообщение в поддержке от ццввцвцв: цауацуа...",
    "is_read": true,
    "created_at": "2026-02-25T08:50:43.091Z"
  }
},
{
  "model": "accounts.notification",
  "pk": 11,
  "fields": {
    "user": [
      "pashokbilashenko335@gmail.com"
    ],
    "message": "Новое сообщение в поддержке от ццввцвцв: уцацуа...",
    "is_read": true,
    "created_at": "2026-02-25T08:50:44.774Z"
  }
},
{
  "model": "accounts.notification",
  "pk": 12,
  "fields": {
    "user": [
      "pashokbilashenko335@gmail.com"
    ],
    "message": "Новое сообщение в поддержке от ццввцвцв: Другая проблема...",
    "is_read": true,
    "created_at": "2026-02-25T08:50:45.261Z"
  }
},
{
  "model": "accounts.notification",
  "pk": 13,
  "fields": {
    "user": [
      "pashokbilashenko335@gmail.com"
    ],
    "message": "Новое сообщение в поддержке от ццввцвцв: ауц...",
    "is_read": true,
    "created_at": "2026-02-25T08:50:49.731Z"
  }
},
{
  "model": "accounts.notification",
  "pk": 14,
  "fields": {
    "user": [
      "lehaprorok228@gmail.com"
    ],
    "message": "Администратор ответил: сыы...",
    "is_read": false,
    "created_at": "2026-02-25T08:51:18.267Z"
  }
},
{
  "model": "accounts.notification",
  "pk": 15,
  "fields": {
    "user": [
      "lehaprorok228@gmail.com"
    ],
    "message": "Администратор ответил: оо...",
    "is_read": false,
    "created_at": "2026-02-26T18:20:38.914Z"
  }
},
{
  "model": "courses.course",
  "pk": 1,
  "fields": {
    "title": "уацу",
    "description": "ауцуац",
    "programming_language": "python",
    "instructor": [
      "author@progauge.com"
    ],
    "level": "beginner",
    "image": "courses/Снимок_экрана_2026-02-18_202941.png",
    "price": "0.00",
    "created_at": "2026-02-20T09:22:09.267Z",
    "updated_at": "2026-02-20T09:22:09.267Z"
  }
},
{
  "model": "courses.courseenrollment",
  "pk": 1,
  "fields": {
    "course": 1,
    "student": [
      "pashokbilashenko335@gmail.com"
    ],
    "enrolled_at": "2026-02-20T09:22:32.975Z",
    "completed": false
  }
},
{
  "model": "courses.courseenrollment",
  "pk": 5,
  "fields": {
    "course": 1,
    "student": [
      "lehaprorok228@gmail.com"
    ],
    "enrolled_at": "2026-02-20T16:02:33.998Z",
    "completed": false
  }
},
{
  "model": "courses.courselike",
  "pk": 1,
  "fields": {
    "course": 1,
    "user": [
      "pashokbilashenko335@gmail.com"
    ],
    "created_at": "2026-02-20T09:23:01.185Z"
  }
},
{
  "model": "courses.courselike",
  "pk": 5,
  "fields": {
    "course": 1,
    "user": [
      "lehaprorok228@gmail.com"
    ],
    "created_at": "2026-02-20T16:02:36.513Z"
  }
},
{
  "model": "courses.coursereview",
  "pk": 1,
  "fields": {
    "course": 1,
    "user": [
      "pashokbilashenko335@gmail.com"
    ],
    "rating": 1,
    "comment": "",
    "created_at": "2026-02-20T09:22:41.547Z"
  }
},
{
  "model": "courses.coursereview",
  "pk": 2,
  "fields": {
    "course": 1,
    "user": [
      "author@progauge.com"
    ],
    "rating": 4,
    "comment": "",
    "created_at": "2026-02-20T09:50:58.641Z"
  }
},
{
  "model": "courses.coursereview",
  "pk": 3,
  "fields": {
    "course": 1,
    "user": [
      "lehaprorok228@gmail.com"
    ],
    "rating": 3,
    "comment": "оппг",
    "created_at": "2026-02-20T16:02:38.839Z"
  }
},
{
  "model": "adminpanel.systemlog",
  "pk": 1,
  "fields": {
    "level": "ERROR",
    "message": "Unhandled exception: Invalid filter: 'div'",
    "timestamp": "2026-02-26T19:05:10.330Z",
    "module": "django.template.exceptions",
    "function": "TemplateSyntaxError",
    "line_number": null,
    "user": [
      "pashokbilashenko335@gmail.com"
    ],
    "ip_address": "127.0.0.1",
    "request_id": "f7094b44-bba5-4b38-b52b-7930da9c7053",
    "extra_data": {
      "exception_type": "TemplateSyntaxError"
    }
  }
},
{
  "model": "adminpanel.systemlog",
  "pk": 2,
  "fields": {
    "level": "ERROR",
    "message": "Unhandled exception: Could not parse the remainder: '*1024' from '1024*1024'",
    "timestamp": "2026-02-26T19:15:28.303Z",
    "module": "django.template.exceptions",
    "function": "TemplateSyntaxError",
    "line_number": null,
    "user": [
      "pashokbilashenko335@gmail.com"
    ],
    "ip_address": "127.0.0.1",
    "request_id": "3367cdaa-6d93-4a91-a691-38e0ba572c02",
    "extra_data": {
      "exception_type": "TemplateSyntaxError"
    }
  }
},
{
  "model": "adminpanel.backuplog",
  "pk": 1,
  "fields": {
    "backup_type": "full",
    "status": "completed",
    "started_at": "2026-02-26T19:15:28.191Z",
    "completed_at": "2026-02-26T19:15:28.194Z",
    "file_path": "/backups/backup_20260226_191528.sql",
    "file_size": 1048576,
    "tables_count": 10,
    "records_count": 1000,
    "error_message": null,
    "created_by": [
      "pashokbilashenko335@gmail.com"
    ],
    "description": ""
  }
},
{
  "model": "adminpanel.usersession",
  "pk": 1,
  "fields": {
    "user": [
      "pashokbilashenko335@gmail.com"
    ],
    "session_key": "s1wqfo2dt23z5kwtucj8ns6tre2iqdir",
    "ip_address": "127.0.0.1",
    "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0",
    "started_at": "2026-02-26T18:52:06.228Z",
    "last_activity": "2026-02-26T20:28:25.641Z",
    "is_active": true,
    "page_views": 275
  }
},
{
  "model": "adminpanel.errorlog",
  "pk": 1,
  "fields": {
    "error_type": "python",
    "message": "Invalid filter: 'div'",
    "stack_trace": "Traceback (most recent call last):\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\core\\handlers\\base.py\", line 197, in _get_response\n    response = wrapped_callback(request, *callback_args, **callback_kwargs)\n  File \"C:\\Progage\\adminpanel\\decorators.py\", line 14, in _wrapped_view\n    return view_func(request, *args, **kwargs)\n  File \"C:\\Progage\\adminpanel\\views.py\", line 217, in user_sessions\n    return render(request, 'adminpanel/user_sessions.html', context)\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\shortcuts.py\", line 25, in render\n    content = loader.render_to_string(template_name, context, request, using=using)\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\loader.py\", line 61, in render_to_string\n    template = get_template(template_name, using=using)\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\loader.py\", line 15, in get_template\n    return engine.get_template(template_name)\n           ~~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\backends\\django.py\", line 79, in get_template\n    return Template(self.engine.get_template(template_name), self)\n                    ~~~~~~~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\engine.py\", line 177, in get_template\n    template, origin = self.find_template(template_name)\n                       ~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\engine.py\", line 159, in find_template\n    template = loader.get_template(name, skip=skip)\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\loaders\\cached.py\", line 57, in get_template\n    template = super().get_template(template_name, skip)\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\loaders\\base.py\", line 28, in get_template\n    return Template(\n        contents,\n    ...<2 lines>...\n        self.engine,\n    )\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\base.py\", line 154, in __init__\n    self.nodelist = self.compile_nodelist()\n                    ~~~~~~~~~~~~~~~~~~~~~^^\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\base.py\", line 196, in compile_nodelist\n    nodelist = parser.parse()\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\base.py\", line 518, in parse\n    raise self.error(token, e)\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\base.py\", line 516, in parse\n    compiled_result = compile_func(self, token)\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\loader_tags.py\", line 295, in do_extends\n    nodelist = parser.parse()\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\base.py\", line 518, in parse\n    raise self.error(token, e)\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\base.py\", line 516, in parse\n    compiled_result = compile_func(self, token)\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\loader_tags.py\", line 234, in do_block\n    nodelist = parser.parse((\"endblock\",))\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\base.py\", line 518, in parse\n    raise self.error(token, e)\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\base.py\", line 516, in parse\n    compiled_result = compile_func(self, token)\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\defaulttags.py\", line 962, in do_if\n    nodelist = parser.parse((\"elif\", \"else\", \"endif\"))\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\base.py\", line 518, in parse\n    raise self.error(token, e)\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\base.py\", line 516, in parse\n    compiled_result = compile_func(self, token)\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\defaulttags.py\", line 862, in do_for\n    nodelist_loop = parser.parse(\n        (\n    ...<2 lines>...\n        )\n    )\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\base.py\", line 489, in parse\n    raise self.error(token, e)\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\base.py\", line 487, in parse\n    filter_expression = self.compile_filter(token.contents)\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\base.py\", line 605, in compile_filter\n    return FilterExpression(token, self)\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\base.py\", line 701, in __init__\n    filter_func = parser.find_filter(filter_name)\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\base.py\", line 611, in find_filter\n    raise TemplateSyntaxError(\"Invalid filter: '%s'\" % filter_name)\ndjango.template.exceptions.TemplateSyntaxError: Invalid filter: 'div'\n",
    "url": "/adminpanel/logs/sessions/",
    "method": "GET",
    "user": [
      "pashokbilashenko335@gmail.com"
    ],
    "ip_address": "127.0.0.1",
    "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0",
    "timestamp": "2026-02-26T19:05:10.317Z",
    "resolved": false,
    "resolved_at": null,
    "resolved_by": null
  }
},
{
  "model": "adminpanel.errorlog",
  "pk": 2,
  "fields": {
    "error_type": "500",
    "message": "HTTP 500 error",
    "stack_trace": null,
    "url": "/adminpanel/logs/sessions/",
    "method": "GET",
    "user": [
      "pashokbilashenko335@gmail.com"
    ],
    "ip_address": "127.0.0.1",
    "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0",
    "timestamp": "2026-02-26T19:05:10.393Z",
    "resolved": false,
    "resolved_at": null,
    "resolved_by": null
  }
},
{
  "model": "adminpanel.errorlog",
  "pk": 3,
  "fields": {
    "error_type": "python",
    "message": "Could not parse the remainder: '*1024' from '1024*1024'",
    "stack_trace": "Traceback (most recent call last):\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\smartif.py\", line 180, in translate_token\n    op = OPERATORS[token]\n         ~~~~~~~~~^^^^^^^\nKeyError: '1024*1024'\n\nDuring handling of the above exception, another exception occurred:\n\nTraceback (most recent call last):\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\core\\handlers\\base.py\", line 197, in _get_response\n    response = wrapped_callback(request, *callback_args, **callback_kwargs)\n  File \"C:\\Progage\\adminpanel\\decorators.py\", line 14, in _wrapped_view\n    return view_func(request, *args, **kwargs)\n  File \"C:\\Progage\\adminpanel\\views.py\", line 286, in backup_logs\n    return render(request, 'adminpanel/backup_logs.html', context)\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\shortcuts.py\", line 25, in render\n    content = loader.render_to_string(template_name, context, request, using=using)\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\loader.py\", line 61, in render_to_string\n    template = get_template(template_name, using=using)\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\loader.py\", line 15, in get_template\n    return engine.get_template(template_name)\n           ~~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\backends\\django.py\", line 79, in get_template\n    return Template(self.engine.get_template(template_name), self)\n                    ~~~~~~~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\engine.py\", line 177, in get_template\n    template, origin = self.find_template(template_name)\n                       ~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\engine.py\", line 159, in find_template\n    template = loader.get_template(name, skip=skip)\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\loaders\\cached.py\", line 57, in get_template\n    template = super().get_template(template_name, skip)\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\loaders\\base.py\", line 28, in get_template\n    return Template(\n        contents,\n    ...<2 lines>...\n        self.engine,\n    )\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\base.py\", line 154, in __init__\n    self.nodelist = self.compile_nodelist()\n                    ~~~~~~~~~~~~~~~~~~~~~^^\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\base.py\", line 196, in compile_nodelist\n    nodelist = parser.parse()\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\base.py\", line 518, in parse\n    raise self.error(token, e)\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\base.py\", line 516, in parse\n    compiled_result = compile_func(self, token)\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\loader_tags.py\", line 295, in do_extends\n    nodelist = parser.parse()\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\base.py\", line 518, in parse\n    raise self.error(token, e)\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\base.py\", line 516, in parse\n    compiled_result = compile_func(self, token)\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\loader_tags.py\", line 234, in do_block\n    nodelist = parser.parse((\"endblock\",))\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\base.py\", line 518, in parse\n    raise self.error(token, e)\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\base.py\", line 516, in parse\n    compiled_result = compile_func(self, token)\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\defaulttags.py\", line 962, in do_if\n    nodelist = parser.parse((\"elif\", \"else\", \"endif\"))\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\base.py\", line 518, in parse\n    raise self.error(token, e)\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\base.py\", line 516, in parse\n    compiled_result = compile_func(self, token)\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\defaulttags.py\", line 862, in do_for\n    nodelist_loop = parser.parse(\n        (\n    ...<2 lines>...\n        )\n    )\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\base.py\", line 518, in parse\n    raise self.error(token, e)\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\base.py\", line 516, in parse\n    compiled_result = compile_func(self, token)\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\defaulttags.py\", line 962, in do_if\n    nodelist = parser.parse((\"elif\", \"else\", \"endif\"))\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\base.py\", line 518, in parse\n    raise self.error(token, e)\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\base.py\", line 516, in parse\n    compiled_result = compile_func(self, token)\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\defaulttags.py\", line 961, in do_if\n    condition = TemplateIfParser(parser, bits).parse()\n                ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\defaulttags.py\", line 894, in __init__\n    super().__init__(*args, **kwargs)\n    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\smartif.py\", line 171, in __init__\n    mapped_tokens.append(self.translate_token(token))\n                         ~~~~~~~~~~~~~~~~~~~~^^^^^^^\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\smartif.py\", line 182, in translate_token\n    return self.create_var(token)\n           ~~~~~~~~~~~~~~~^^^^^^^\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\defaulttags.py\", line 897, in create_var\n    return TemplateLiteral(self.template_parser.compile_filter(value), value)\n                           ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~^^^^^^^\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\base.py\", line 605, in compile_filter\n    return FilterExpression(token, self)\n  File \"C:\\Users\\Кирилл\\AppData\\Roaming\\Python\\Python314\\site-packages\\django\\template\\base.py\", line 706, in __init__\n    raise TemplateSyntaxError(\n    ...<2 lines>...\n    )\ndjango.template.exceptions.TemplateSyntaxError: Could not parse the remainder: '*1024' from '1024*1024'\n",
    "url": "/adminpanel/backups/",
    "method": "GET",
    "user": [
      "pashokbilashenko335@gmail.com"
    ],
    "ip_address": "127.0.0.1",
    "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0",
    "timestamp": "2026-02-26T19:15:28.300Z",
    "resolved": false,
    "resolved_at": null,
    "resolved_by": null
  }
},
{
  "model": "adminpanel.errorlog",
  "pk": 4,
  "fields": {
    "error_type": "500",
    "message": "HTTP 500 error",
    "stack_trace": null,
    "url": "/adminpanel/backups/",
    "method": "GET",
    "user": [
      "pashokbilashenko335@gmail.com"
    ],
    "ip_address": "127.0.0.1",
    "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0",
    "timestamp": "2026-02-26T19:15:28.356Z",
    "resolved": false,
    "resolved_at": null,
    "resolved_by": null
  }
},
{
  "model": "chat.supportchat",
  "pk": 1,
  "fields": {
    "user": [
      "lehaprorok228@gmail.com"
    ],
    "admin": [
      "pashokbilashenko335@gmail.com"
    ],
    "status": "closed",
    "priority": true,
    "created_at": "2026-02-20T16:41:33.060Z",
    "updated_at": "2026-02-26T18:20:29.533Z"
  }
},
{
  "model": "chat.message",
  "pk": 1,
  "fields": {
    "chat": 1,
    "sender": [
      "lehaprorok228@gmail.com"
    ],
    "text": "Как выбрать подходящий курс?",
    "timestamp": "2026-02-20T16:47:15.141Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 2,
  "fields": {
    "chat": 1,
    "sender": [
      "pashokbilashenko335@gmail.com"
    ],
    "text": "Для выбора курса учитывайте ваш уровень знаний, цели и время. Посмотрите описания курсов и отзывы.",
    "timestamp": "2026-02-20T16:47:15.147Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 3,
  "fields": {
    "chat": 1,
    "sender": [
      "lehaprorok228@gmail.com"
    ],
    "text": "Проблема с оплатой",
    "timestamp": "2026-02-20T16:47:20.690Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 4,
  "fields": {
    "chat": 1,
    "sender": [
      "pashokbilashenko335@gmail.com"
    ],
    "text": "Если проблема с оплатой, проверьте данные карты или свяжитесь с банком. Курсы бесплатны, но для премиум фич может требоваться оплата.",
    "timestamp": "2026-02-20T16:47:20.693Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 5,
  "fields": {
    "chat": 1,
    "sender": [
      "lehaprorok228@gmail.com"
    ],
    "text": "Другая проблема",
    "timestamp": "2026-02-20T16:47:24.144Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 6,
  "fields": {
    "chat": 1,
    "sender": [
      "lehaprorok228@gmail.com"
    ],
    "text": "Как так вышло?",
    "timestamp": "2026-02-20T16:47:31.012Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 7,
  "fields": {
    "chat": 1,
    "sender": [
      "pashokbilashenko335@gmail.com"
    ],
    "text": "ну вот так вот",
    "timestamp": "2026-02-20T16:48:13.468Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 8,
  "fields": {
    "chat": 1,
    "sender": [
      "lehaprorok228@gmail.com"
    ],
    "text": "Проблема с оплатой",
    "timestamp": "2026-02-20T16:54:34.241Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 9,
  "fields": {
    "chat": 1,
    "sender": [
      "pashokbilashenko335@gmail.com"
    ],
    "text": "Если проблема с оплатой, проверьте данные карты или свяжитесь с банком. Курсы бесплатны, но для премиум фич может требоваться оплата.",
    "timestamp": "2026-02-20T16:54:34.247Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 10,
  "fields": {
    "chat": 1,
    "sender": [
      "lehaprorok228@gmail.com"
    ],
    "text": "Проблема с оплатой",
    "timestamp": "2026-02-20T16:54:41.030Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 11,
  "fields": {
    "chat": 1,
    "sender": [
      "pashokbilashenko335@gmail.com"
    ],
    "text": "Если проблема с оплатой, проверьте данные карты или свяжитесь с банком. Курсы бесплатны, но для премиум фич может требоваться оплата.",
    "timestamp": "2026-02-20T16:54:41.035Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 12,
  "fields": {
    "chat": 1,
    "sender": [
      "lehaprorok228@gmail.com"
    ],
    "text": "Проблема с оплатой",
    "timestamp": "2026-02-20T17:06:57.698Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 13,
  "fields": {
    "chat": 1,
    "sender": [
      "pashokbilashenko335@gmail.com"
    ],
    "text": "Если проблема с оплатой, проверьте данные карты или свяжитесь с банком. Курсы бесплатны, но для премиум фич может требоваться оплата.",
    "timestamp": "2026-02-20T17:06:57.705Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 14,
  "fields": {
    "chat": 1,
    "sender": [
      "lehaprorok228@gmail.com"
    ],
    "text": "Проблема с оплатой",
    "timestamp": "2026-02-20T17:08:56.418Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 15,
  "fields": {
    "chat": 1,
    "sender": [
      "pashokbilashenko335@gmail.com"
    ],
    "text": "Если проблема с оплатой, проверьте данные карты или свяжитесь с банком. Курсы бесплатны, но для премиум фич может требоваться оплата.",
    "timestamp": "2026-02-20T17:08:56.424Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 16,
  "fields": {
    "chat": 1,
    "sender": [
      "lehaprorok228@gmail.com"
    ],
    "text": "ыогы",
    "timestamp": "2026-02-20T17:17:14.546Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 17,
  "fields": {
    "chat": 1,
    "sender": [
      "lehaprorok228@gmail.com"
    ],
    "text": "Проблема с оплатой",
    "timestamp": "2026-02-20T18:42:28.592Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 18,
  "fields": {
    "chat": 1,
    "sender": [
      "pashokbilashenko335@gmail.com"
    ],
    "text": "Если проблема с оплатой, проверьте данные карты или свяжитесь с банком. Курсы бесплатны, но для премиум фич может требоваться оплата.",
    "timestamp": "2026-02-20T18:42:28.602Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 19,
  "fields": {
    "chat": 1,
    "sender": [
      "lehaprorok228@gmail.com"
    ],
    "text": "Проблема с оплатой",
    "timestamp": "2026-02-20T18:42:40.230Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 20,
  "fields": {
    "chat": 1,
    "sender": [
      "pashokbilashenko335@gmail.com"
    ],
    "text": "Если проблема с оплатой, проверьте данные карты или свяжитесь с банком. Курсы бесплатны, но для премиум фич может требоваться оплата.",
    "timestamp": "2026-02-20T18:42:40.235Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 21,
  "fields": {
    "chat": 1,
    "sender": [
      "lehaprorok228@gmail.com"
    ],
    "text": "Проблема с оплатой",
    "timestamp": "2026-02-20T19:13:03.351Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 22,
  "fields": {
    "chat": 1,
    "sender": [
      "pashokbilashenko335@gmail.com"
    ],
    "text": "Если проблема с оплатой, проверьте данные карты или свяжитесь с банком. Курсы бесплатны, но для премиум фич может требоваться оплата.",
    "timestamp": "2026-02-20T19:13:03.363Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 23,
  "fields": {
    "chat": 1,
    "sender": [
      "pashokbilashenko335@gmail.com"
    ],
    "text": "ыыфы",
    "timestamp": "2026-02-20T19:15:52.320Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 24,
  "fields": {
    "chat": 1,
    "sender": [
      "pashokbilashenko335@gmail.com"
    ],
    "text": "ыыввы",
    "timestamp": "2026-02-20T19:20:59.343Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 25,
  "fields": {
    "chat": 1,
    "sender": [
      "pashokbilashenko335@gmail.com"
    ],
    "text": "jhhj",
    "timestamp": "2026-02-20T19:22:29.321Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 26,
  "fields": {
    "chat": 1,
    "sender": [
      "pashokbilashenko335@gmail.com"
    ],
    "text": "вцауц",
    "timestamp": "2026-02-20T19:25:53.296Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 27,
  "fields": {
    "chat": 1,
    "sender": [
      "pashokbilashenko335@gmail.com"
    ],
    "text": "ув",
    "timestamp": "2026-02-20T19:27:09.592Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 28,
  "fields": {
    "chat": 1,
    "sender": [
      "pashokbilashenko335@gmail.com"
    ],
    "text": "увау",
    "timestamp": "2026-02-20T19:32:15.052Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 29,
  "fields": {
    "chat": 1,
    "sender": [
      "lehaprorok228@gmail.com"
    ],
    "text": "Проблема с оплатой",
    "timestamp": "2026-02-20T19:32:35.453Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 30,
  "fields": {
    "chat": 1,
    "sender": [
      "pashokbilashenko335@gmail.com"
    ],
    "text": "Если проблема с оплатой, проверьте данные карты или свяжитесь с банком. Курсы бесплатны, но для премиум фич может требоваться оплата.",
    "timestamp": "2026-02-20T19:32:35.461Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 31,
  "fields": {
    "chat": 1,
    "sender": [
      "lehaprorok228@gmail.com"
    ],
    "text": "Проблема с оплатой",
    "timestamp": "2026-02-20T19:42:58.516Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 32,
  "fields": {
    "chat": 1,
    "sender": [
      "pashokbilashenko335@gmail.com"
    ],
    "text": "Если проблема с оплатой, проверьте данные карты или свяжитесь с банком. Курсы бесплатны, но для премиум фич может требоваться оплата.",
    "timestamp": "2026-02-20T19:42:58.522Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 33,
  "fields": {
    "chat": 1,
    "sender": [
      "lehaprorok228@gmail.com"
    ],
    "text": "Как выбрать подходящий курс?",
    "timestamp": "2026-02-20T19:42:59.568Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 34,
  "fields": {
    "chat": 1,
    "sender": [
      "pashokbilashenko335@gmail.com"
    ],
    "text": "Для выбора курса учитывайте ваш уровень знаний, цели и время. Посмотрите описания курсов и отзывы.",
    "timestamp": "2026-02-20T19:42:59.573Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 35,
  "fields": {
    "chat": 1,
    "sender": [
      "lehaprorok228@gmail.com"
    ],
    "text": "Другая проблема",
    "timestamp": "2026-02-20T19:43:00.461Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 36,
  "fields": {
    "chat": 1,
    "sender": [
      "lehaprorok228@gmail.com"
    ],
    "text": "шгрш",
    "timestamp": "2026-02-20T19:43:03.260Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 37,
  "fields": {
    "chat": 1,
    "sender": [
      "pashokbilashenko335@gmail.com"
    ],
    "text": "igyfuy",
    "timestamp": "2026-02-24T08:35:48.708Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 38,
  "fields": {
    "chat": 1,
    "sender": [
      "lehaprorok228@gmail.com"
    ],
    "text": "Как выбрать подходящий курс?",
    "timestamp": "2026-02-24T08:35:59.934Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 39,
  "fields": {
    "chat": 1,
    "sender": [
      "pashokbilashenko335@gmail.com"
    ],
    "text": "Для выбора курса учитывайте ваш уровень знаний, цели и время. Посмотрите описания курсов и отзывы.",
    "timestamp": "2026-02-24T08:35:59.939Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 40,
  "fields": {
    "chat": 1,
    "sender": [
      "lehaprorok228@gmail.com"
    ],
    "text": "Проблема с оплатой",
    "timestamp": "2026-02-24T08:36:00.723Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 41,
  "fields": {
    "chat": 1,
    "sender": [
      "pashokbilashenko335@gmail.com"
    ],
    "text": "Если проблема с оплатой, проверьте данные карты или свяжитесь с банком. Курсы бесплатны, но для премиум фич может требоваться оплата.",
    "timestamp": "2026-02-24T08:36:00.729Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 42,
  "fields": {
    "chat": 1,
    "sender": [
      "lehaprorok228@gmail.com"
    ],
    "text": "Другая проблема",
    "timestamp": "2026-02-24T08:36:02.655Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 43,
  "fields": {
    "chat": 1,
    "sender": [
      "lehaprorok228@gmail.com"
    ],
    "text": "Проблема с оплатой",
    "timestamp": "2026-02-25T08:45:35.631Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 44,
  "fields": {
    "chat": 1,
    "sender": [
      "pashokbilashenko335@gmail.com"
    ],
    "text": "Если проблема с оплатой, проверьте данные карты или свяжитесь с банком. Курсы бесплатны, но для премиум фич может требоваться оплата.",
    "timestamp": "2026-02-25T08:45:35.638Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 45,
  "fields": {
    "chat": 1,
    "sender": [
      "pashokbilashenko335@gmail.com"
    ],
    "text": "ининр",
    "timestamp": "2026-02-25T08:45:53.168Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 46,
  "fields": {
    "chat": 1,
    "sender": [
      "lehaprorok228@gmail.com"
    ],
    "text": "цауца",
    "timestamp": "2026-02-25T08:50:41.639Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 47,
  "fields": {
    "chat": 1,
    "sender": [
      "lehaprorok228@gmail.com"
    ],
    "text": "цауацуа",
    "timestamp": "2026-02-25T08:50:43.088Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 48,
  "fields": {
    "chat": 1,
    "sender": [
      "lehaprorok228@gmail.com"
    ],
    "text": "уцацуа",
    "timestamp": "2026-02-25T08:50:44.769Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 49,
  "fields": {
    "chat": 1,
    "sender": [
      "lehaprorok228@gmail.com"
    ],
    "text": "Другая проблема",
    "timestamp": "2026-02-25T08:50:45.257Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 50,
  "fields": {
    "chat": 1,
    "sender": [
      "lehaprorok228@gmail.com"
    ],
    "text": "ауц",
    "timestamp": "2026-02-25T08:50:49.728Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 51,
  "fields": {
    "chat": 1,
    "sender": [
      "pashokbilashenko335@gmail.com"
    ],
    "text": "сыы",
    "timestamp": "2026-02-25T08:51:18.265Z",
    "is_read": false
  }
},
{
  "model": "chat.message",
  "pk": 52,
  "fields": {
    "chat": 1,
    "sender": [
      "pashokbilashenko335@gmail.com"
    ],
    "text": "оо",
    "timestamp": "2026-02-26T18:20:38.890Z",
    "is_read": false
  }
}
]
